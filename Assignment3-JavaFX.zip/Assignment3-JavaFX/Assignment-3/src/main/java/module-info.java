module com.group8.assignment3 {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;

    opens com.group8.assignment3 to javafx.fxml;
    exports com.group8.assignment3;
}