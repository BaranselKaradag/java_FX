package com.group8.assignment3;

public abstract class Model {
    // Abstract method to be implemented by subclasses to calculate the mean of three values
    public abstract double calculateMean(double value1, double value2, double value3);
}

